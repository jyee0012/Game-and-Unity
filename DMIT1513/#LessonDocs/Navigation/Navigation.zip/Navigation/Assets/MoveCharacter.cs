﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class MoveCharacter : MonoBehaviour
{
    [SerializeField]
    GameObject selectedUnit;
    RaycastHit hit;
    [SerializeField]
    GameObject mainCam;

    void Start()
    {
        mainCam = GameObject.Find("Main Camera");
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {            
            Ray ray = mainCam.GetComponent<Camera>().ScreenPointToRay(Input.mousePosition);
            if (Physics.Raycast(ray, out hit))
            {
                Debug.Log(hit.transform.tag);
                if (hit.transform.tag == "Moveable")
                {
                    selectedUnit = hit.transform.gameObject;
                }
                else if (selectedUnit != null)
                {
                    selectedUnit.GetComponent<NavMeshAgent>().SetDestination(hit.point);
                }
            }                
        }
        if (Input.GetMouseButtonDown(1) && selectedUnit != null)
        {
            selectedUnit = null;
        }
    }
}
